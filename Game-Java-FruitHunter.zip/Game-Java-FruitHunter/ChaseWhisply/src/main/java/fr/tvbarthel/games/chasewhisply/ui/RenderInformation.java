package fr.tvbarthel.games.chasewhisply.ui;


public class RenderInformation {
    public float mPositionX = 0;
    public float mPositionY = 0;
    public float mPositionZ = 0;
    public boolean isOnScreen = false;
}
