package fr.tvbarthel.games.chasewhisply.beta;

public class BetaUtils {
    public static final String KEY_SHARED_PREFERENCES = "BetaKeySharedPreferences";
    public static final String KEY_SENSOR_DELAY = "BetaKeySensorDelay";
    public static final String KEY_COMPATIBILITY_MODE_ACTIVATED = "BetaKeyCompatibilityModeActivated";
}
